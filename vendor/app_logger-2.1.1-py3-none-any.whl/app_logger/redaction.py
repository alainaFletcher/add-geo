"""
Secret redaction and sanitization for the app_logger package.

This module provides defense-in-depth redaction of secrets from log output.
All regex patterns are compiled at module level for performance -- these
functions run on every log line.

Public API:
    - ``REDACT_KEYS``          -- Key name substrings that indicate secrets.
    - ``SECRET_PATTERNS``      -- Compiled regex patterns for known secret formats.
    - ``RESERVED_KEYS``        -- Tier 1/2 field names protected from injection.
    - ``redact_value()``       -- Scrub known secret patterns from a string value.
    - ``should_redact_key()``  -- Check if a key name suggests a secret.
    - ``sanitize_error_message()`` -- Specialized sanitizer for exception messages.
"""

from __future__ import annotations

import re

# ── Known secret key-name substrings ─────────────────────────────────────────
# If any of these appear (case-insensitive) as a substring of an extra-field
# key name, the entire value is replaced with ``[REDACTED]``.

REDACT_KEYS: frozenset[str] = frozenset({
    "password",
    "secret",
    "token",
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "private_key",
    "ssn",
    "access_token",
    "refresh_token",
    "database_url",
    "connection_string",
})

# ── Compiled regex patterns for secret values ────────────────────────────────
# Each pattern is compiled once at import time.  ``redact_value()`` iterates
# through them and replaces matches with ``[REDACTED]``.

_RE_AWS_ACCESS_KEY = re.compile(r"(?:AKIA|ASIA)[0-9A-Z]{16}")

_RE_JWT_TOKEN = re.compile(
    r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
)

_RE_URI_CREDENTIALS = re.compile(
    r"://[^@\s]+:[^@\s]+@"
)

# Bearer / Basic auth tokens in header values
_RE_BEARER_TOKEN = re.compile(
    r"Bearer\s+[A-Za-z0-9\-._~+/]+=*"
)

# GitHub personal access tokens and fine-grained tokens
_RE_GITHUB_TOKEN = re.compile(
    r"(?:ghp|gho|ghu|ghs|ghr|github_pat)_[A-Za-z0-9_]{36,255}"
)

# Slack bot, user, and app tokens
_RE_SLACK_TOKEN = re.compile(
    r"xox[bpars]-[0-9A-Za-z\-]{10,}"
)

# Generic high-entropy base64 strings that look like API keys:
# 20+ chars of base64-alphabet without spaces, starting with a word boundary.
# Requires at least one digit AND one uppercase letter to reduce false positives
# on ordinary English words or module paths.
_RE_HIGH_ENTROPY_KEY = re.compile(
    r"\b(?=[A-Za-z0-9+/=_-]*[0-9])(?=[A-Za-z0-9+/=_-]*[A-Z])"
    r"[A-Za-z0-9+/=_-]{40,}\b"
)

SECRET_PATTERNS: tuple[re.Pattern[str], ...] = (
    _RE_AWS_ACCESS_KEY,
    _RE_JWT_TOKEN,
    _RE_URI_CREDENTIALS,
    _RE_BEARER_TOKEN,
    _RE_GITHUB_TOKEN,
    _RE_SLACK_TOKEN,
    _RE_HIGH_ENTROPY_KEY,
)

# ── Connection-string patterns for sanitize_error_message() ──────────────────
# These are more targeted than the generic URI pattern and handle common
# formats found in SQLAlchemy, pyodbc, and generic database exception messages.

# SQLAlchemy / generic URI:  scheme://user:password@host
_RE_SQLALCHEMY_URI = re.compile(
    r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.-]*)://"
    r"(?P<user>[^:@\s]+):"
    r"(?P<password>[^@\s]+)"
    r"@(?P<host>[^\s,;'\"]+)"
)

# ODBC-style connection strings:  PWD=...;  or  Password=...;
_RE_ODBC_PASSWORD = re.compile(
    r"(?i)(?:PWD|Password)\s*=\s*(?P<password>[^;\s'\"]+)"
)

# Generic ://user:pass@host (same as the value-scrubbing pattern but used
# inside sanitize_error_message for explicit replacement with scheme intact).
_RE_GENERIC_URI_CREDS = re.compile(
    r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.-]*)://"
    r"[^@\s]+:[^@\s]+"
    r"@(?P<host>[^\s,;'\"]+)"
)


# ── Reserved keys (log-injection prevention) ─────────────────────────────────
# Tier 1 and Tier 2 field names that must NOT be overridden by caller-supplied
# extra kwargs.  This prevents log injection where an attacker could overwrite
# ``ts``, ``level``, ``host``, etc.

RESERVED_KEYS: frozenset[str] = frozenset({
    "ts",
    "level",
    "schema_version",
    "logger",
    "message",
    "module",
    "func",
    "line",
    "host",
    "pid",
})


# ── Public functions ─────────────────────────────────────────────────────────


def redact_value(val: str) -> str:
    """Scrub known secret patterns from a string value.

    Iterates through ``SECRET_PATTERNS`` and replaces every match with
    ``[REDACTED]``.  Safe to call on any string; non-matching strings are
    returned unchanged.

    Args:
        val: The string value to scan and scrub.

    Returns:
        The input string with secret patterns replaced by ``[REDACTED]``.
    """
    for pattern in SECRET_PATTERNS:
        val = pattern.sub("[REDACTED]", val)
    return val


def should_redact_key(key: str) -> bool:
    """Check if a key name suggests it contains a secret.

    Performs a case-insensitive substring match against every entry in
    ``REDACT_KEYS``.

    Args:
        key: The field/key name to check.

    Returns:
        ``True`` if the key matches a known secret name pattern.
    """
    key_lower = key.lower()
    return any(secret_key in key_lower for secret_key in REDACT_KEYS)


def sanitize_error_message(msg: str) -> str:
    """Specialized sanitizer for exception messages.

    Handles connection strings commonly leaked in database exception messages:

    - **SQLAlchemy connection URLs:**
      ``postgresql+psycopg2://user:pass@host/db`` becomes
      ``postgresql+psycopg2://user:***@host/db``
    - **ODBC connection strings:**
      ``PWD=secret123;`` becomes ``PWD=***;``
    - **Generic URI credentials:**
      ``mysql://root:password@host`` becomes ``mysql://***:***@host``

    After targeted replacements, the result is also passed through
    ``redact_value()`` for defense-in-depth.

    Args:
        msg: The raw exception message or error detail string.

    Returns:
        A sanitized copy of the message with credentials replaced.
    """
    # 1. SQLAlchemy-style URIs: preserve scheme and host, mask user:pass
    def _replace_sqlalchemy(m: re.Match[str]) -> str:
        return f"{m.group('scheme')}://***:***@{m.group('host')}"

    result = _RE_SQLALCHEMY_URI.sub(_replace_sqlalchemy, msg)

    # 2. ODBC Password fields
    result = _RE_ODBC_PASSWORD.sub(
        lambda m: m.group(0).split("=")[0] + "=***",
        result,
    )

    # 3. Defense-in-depth: run the generic value patterns
    result = redact_value(result)

    return result
