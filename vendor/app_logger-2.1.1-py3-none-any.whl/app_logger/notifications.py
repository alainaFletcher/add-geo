"""Email and Microsoft Teams notification dispatcher for app_logger.

Single module, plain functions and small dataclasses. No new dependencies —
uses stdlib smtplib + urllib.request.

Called by AppLogger.finish() when notify=True. Each channel is independently
configured via NOTIFICATION_* environment variables. On any failure in any
channel, logs a warning and returns — never raises.

This file is built up across plan Tasks 6–11. Task 6 adds settings dataclasses;
later tasks add trigger logic, body builders, and channel senders.
"""
from __future__ import annotations

import json
import logging
import os
import smtplib
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from email.message import EmailMessage

logger = logging.getLogger(__name__)

NOTIFICATION_TIMEOUT_SECONDS = 30
EMAIL_MAX_RECORDS = 50
TEAMS_MAX_RECORDS = 25


# ── Settings dataclasses ──────────────────────────────────────────────────────


@dataclass
class EmailSettings:
    enabled: bool = False
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_use_tls: bool = True
    from_addr: str = ""
    to_addrs: list[str] = field(default_factory=list)
    username: str = ""
    password: str = field(default="", repr=False)

    def is_valid(self) -> bool:
        return (
            self.enabled
            and bool(self.smtp_host)
            and bool(self.from_addr)
            and bool(self.to_addrs)
        )


@dataclass
class TeamsSettings:
    enabled: bool = False
    webhook_url: str = ""

    def is_valid(self) -> bool:
        return self.enabled and self.webhook_url.startswith("https://")


@dataclass
class NotificationSettings:
    level: str = "WARNING"
    dashboard_url: str = ""
    email: EmailSettings = field(default_factory=EmailSettings)
    teams: TeamsSettings = field(default_factory=TeamsSettings)

    @classmethod
    def from_env(cls) -> "NotificationSettings":
        """Load notification settings from environment variables."""
        return cls(
            level=os.environ.get("NOTIFICATION_LEVEL", "WARNING").upper(),
            dashboard_url=os.environ.get("NOTIFICATION_DASHBOARD_URL", ""),
            email=EmailSettings(
                enabled=_bool_env("NOTIFICATION_EMAIL_ENABLED"),
                smtp_host=os.environ.get("NOTIFICATION_EMAIL_SMTP_HOST", ""),
                smtp_port=int(os.environ.get("NOTIFICATION_EMAIL_SMTP_PORT", "587")),
                smtp_use_tls=_bool_env("NOTIFICATION_EMAIL_SMTP_USE_TLS", default=True),
                from_addr=os.environ.get("NOTIFICATION_EMAIL_FROM", ""),
                to_addrs=_split_csv(os.environ.get("NOTIFICATION_EMAIL_TO", "")),
                username=os.environ.get("NOTIFICATION_EMAIL_USERNAME", ""),
                password=os.environ.get("NOTIFICATION_EMAIL_PASSWORD", ""),
            ),
            teams=TeamsSettings(
                enabled=_bool_env("NOTIFICATION_TEAMS_ENABLED"),
                webhook_url=os.environ.get("NOTIFICATION_TEAMS_WEBHOOK_URL", ""),
            ),
        )

    def has_any_enabled(self) -> bool:
        return self.email.is_valid() or self.teams.is_valid()


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _split_csv(raw: str) -> list[str]:
    return [p.strip() for p in raw.split(",") if p.strip()]


# ── Trigger logic ─────────────────────────────────────────────────────────────


_LEVEL_RANK = {
    "DEBUG": 10,
    "INFO": 20,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
}


def _should_notify(
    run_summary: dict,
    log_lines: list[dict],
    min_level: str,
) -> bool:
    """Decide whether a notification should fire for this run.

    Returns True if either:
      - run_summary['status'] == 'FAILED', OR
      - any *user-emitted* log line has level >= min_level.

    The synthetic ``event == "RUN_END"`` line that ``AppLogger.finish()``
    writes is excluded from the line scan: its severity is already
    represented by ``run_summary['status']`` (which we special-case
    above for FAILED), so counting it again would double-count and could
    fire alerts for benign outcomes like SKIPPED if ``finish()`` ever
    mis-levels its own line.

    Does not aggregate (e.g., "only if >5 warnings"). One warning fires.
    Unknown min_level values fall back to WARNING (fail-safe — better to
    notify on a misconfiguration than silently swallow alerts).
    """
    if run_summary.get("status") == "FAILED":
        return True
    threshold = _LEVEL_RANK.get(min_level.upper(), _LEVEL_RANK["WARNING"])
    for line in log_lines:
        if line.get("event") == "RUN_END":
            continue
        line_rank = _LEVEL_RANK.get(line.get("level", "INFO").upper(), 0)
        if line_rank >= threshold:
            return True
    return False


# ── Body builders ─────────────────────────────────────────────────────────────


def _format_duration(seconds: float) -> str:
    """Render duration as e.g. '5m 11s' or '1h 23m 45s'."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes, sec = divmod(int(seconds), 60)
    if minutes < 60:
        return f"{minutes}m {sec}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m {sec}s"


def _format_ts(iso_str: str) -> str:
    """Convert an ISO timestamp to a readable form. Falls back to original on parse failure."""
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except (ValueError, AttributeError):
        return iso_str


def _filter_alert_lines(lines: list[dict]) -> list[dict]:
    """Return only WARNING+ lines for the digest."""
    return [
        line for line in lines
        if _LEVEL_RANK.get(line.get("level", "INFO").upper(), 0)
        >= _LEVEL_RANK["WARNING"]
    ]


def _build_subject(run_summary: dict) -> str:
    return (
        f"[{run_summary.get('app', '?')}] "
        f"{run_summary.get('status', '?')}: "
        f"{run_summary.get('error_count', 0)} error(s), "
        f"{run_summary.get('warning_count', 0)} warning(s) "
        f"in {run_summary.get('job', '?')}"
    )


def _build_text_digest(
    run_summary: dict,
    log_lines: list[dict],
    max_records: int = EMAIL_MAX_RECORDS,
    dashboard_url: str = "",
) -> str:
    """Format the plain-text email body."""
    alert_lines = _filter_alert_lines(log_lines)
    total_alerts = len(alert_lines)
    truncated = alert_lines[:max_records]

    lines: list[str] = []
    lines.append(
        f"{run_summary.get('app', '?')} — "
        f"{run_summary.get('job', '?')} — "
        f"{run_summary.get('status', '?')}"
    )
    lines.append("")
    lines.append(f"Run ID:     {run_summary.get('run_id', '?')}")
    lines.append(f"Started:    {_format_ts(run_summary.get('started_at', ''))}")
    lines.append(f"Ended:      {_format_ts(run_summary.get('ended_at', ''))}")
    lines.append(f"Duration:   {_format_duration(run_summary.get('duration_s', 0))}")
    lines.append(
        f"Steps:      {run_summary.get('steps_success', 0)} succeeded, "
        f"{run_summary.get('steps_failed', 0)} failed of "
        f"{run_summary.get('steps_total', 0)} total"
    )
    lines.append(f"Errors:     {run_summary.get('error_count', 0)}")
    lines.append(f"Warnings:   {run_summary.get('warning_count', 0)}")

    failed_steps = run_summary.get("failed_steps", [])
    if failed_steps:
        lines.append("")
        lines.append("Failed steps:")
        for fs in failed_steps:
            lines.append(
                f"  - {fs.get('step', '?')} [{fs.get('status', '?')}]: "
                f"{fs.get('error_type', '')}: {fs.get('error', '')}"
            )

    if truncated:
        lines.append("")
        lines.append(
            f"Recent warnings/errors (showing {len(truncated)} of {total_alerts}):"
        )
        for ln in truncated:
            ts = ln.get("ts", "")
            ts_short = ts[11:19] if len(ts) >= 19 else ""
            step = ln.get("step", "")
            step_part = f"[{step}]" if step else ""
            lines.append(
                f"  [{ts_short}] {ln.get('level', ''):<7} "
                f"{step_part}: {ln.get('message', '')}"
            )

    if dashboard_url:
        lines.append("")
        lines.append(
            f"View the full run: {dashboard_url.rstrip('/')}/run/"
            f"{run_summary.get('run_id', '')}"
        )

    lines.append("")
    lines.append("---")
    lines.append(f"Sent by app_logger from {run_summary.get('host', '?')}.")
    return "\n".join(lines)


_STATUS_TO_CARD_STYLE = {
    "SUCCESS": "good",
    "PARTIAL": "warning",
    "FAILED": "attention",
    "SKIPPED": "default",
}


def _build_adaptive_card(
    run_summary: dict,
    log_lines: list[dict],
    max_records: int = TEAMS_MAX_RECORDS,
    dashboard_url: str = "",
) -> dict:
    """Build a Microsoft Teams Adaptive Card 1.4 payload."""
    style = _STATUS_TO_CARD_STYLE.get(run_summary.get("status", ""), "default")

    facts = [
        {"title": "Run ID", "value": run_summary.get("run_id", "")},
        {"title": "Job", "value": run_summary.get("job", "")},
        {"title": "Status", "value": run_summary.get("status", "")},
        {"title": "Duration", "value": _format_duration(run_summary.get("duration_s", 0))},
        {
            "title": "Steps",
            "value": (
                f"{run_summary.get('steps_success', 0)}/"
                f"{run_summary.get('steps_total', 0)} succeeded"
            ),
        },
        {
            "title": "Errors / Warnings",
            "value": (
                f"{run_summary.get('error_count', 0)} / "
                f"{run_summary.get('warning_count', 0)}"
            ),
        },
    ]

    alert_lines = _filter_alert_lines(log_lines)[:max_records]
    alert_text_parts: list[str] = []
    for ln in alert_lines:
        ts = ln.get("ts", "")
        ts_short = ts[11:19] if len(ts) >= 19 else ""
        step = ln.get("step", "")
        step_part = f"[{step}] " if step else ""
        alert_text_parts.append(
            f"`{ts_short}` **{ln.get('level', '')}** {step_part}{ln.get('message', '')}"
        )

    body: list[dict] = [
        {
            "type": "Container",
            "style": style,
            "items": [
                {
                    "type": "TextBlock",
                    "size": "Large",
                    "weight": "Bolder",
                    "text": f"{run_summary.get('app', '?')} — {run_summary.get('status', '?')}",
                    "wrap": True,
                },
            ],
        },
        {"type": "FactSet", "facts": facts},
    ]

    if alert_text_parts:
        body.append({
            "type": "TextBlock",
            "text": "\n\n".join(alert_text_parts),
            "wrap": True,
            "fontType": "Monospace",
            "size": "Small",
        })

    content: dict = {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body,
    }

    if dashboard_url:
        content["actions"] = [
            {
                "type": "Action.OpenUrl",
                "title": "View run",
                "url": (
                    f"{dashboard_url.rstrip('/')}/run/"
                    f"{run_summary.get('run_id', '')}"
                ),
            }
        ]

    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": content,
            }
        ],
    }


# ── Email channel ─────────────────────────────────────────────────────────────


def _send_email(
    settings: EmailSettings,
    run_summary: dict,
    log_lines: list[dict],
    dashboard_url: str,
) -> None:
    """Send a notification via SMTP. Per-channel exception handling."""
    try:
        msg = EmailMessage()
        msg["Subject"] = _build_subject(run_summary)
        msg["From"] = settings.from_addr
        msg["To"] = ", ".join(settings.to_addrs)
        msg.set_content(
            _build_text_digest(run_summary, log_lines, dashboard_url=dashboard_url)
        )

        with smtplib.SMTP(
            settings.smtp_host,
            settings.smtp_port,
            timeout=NOTIFICATION_TIMEOUT_SECONDS,
        ) as server:
            if settings.smtp_use_tls:
                server.starttls()
            if settings.password:
                username = settings.username or settings.from_addr
                server.login(username, settings.password)
            server.send_message(msg)
        logger.info(
            "Notification email sent (run_id=%s, recipients=%d)",
            run_summary.get("run_id", "?"),
            len(settings.to_addrs),
        )
    except Exception as exc:
        logger.warning(
            "Notification email failed (run_id=%s): %s",
            run_summary.get("run_id", "?"),
            exc,
        )


# ── Teams channel ─────────────────────────────────────────────────────────────


def _send_teams(
    settings: TeamsSettings,
    run_summary: dict,
    log_lines: list[dict],
    dashboard_url: str,
) -> None:
    """POST an Adaptive Card to a Microsoft Teams incoming webhook."""
    try:
        card = _build_adaptive_card(
            run_summary, log_lines, dashboard_url=dashboard_url
        )
        payload = json.dumps(card).encode("utf-8")
        req = urllib.request.Request(
            settings.webhook_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(
            req, timeout=NOTIFICATION_TIMEOUT_SECONDS
        ) as resp:
            resp.read()
        logger.info(
            "Notification Teams card posted (run_id=%s)",
            run_summary.get("run_id", "?"),
        )
    except Exception as exc:
        logger.warning(
            "Notification Teams post failed (run_id=%s): %s",
            run_summary.get("run_id", "?"),
            exc,
        )


# ── Public dispatcher ─────────────────────────────────────────────────────────


def notify_run(
    run_summary: dict,
    log_lines: list[dict],
    settings: NotificationSettings,
) -> None:
    """Evaluate triggers and dispatch notifications.

    Called by AppLogger.finish() when notify=True. Each channel send
    is wrapped in its own try/except so one broken channel doesn't block
    the others. Never raises.
    """
    try:
        if not _should_notify(run_summary, log_lines, settings.level):
            return

        if settings.email.is_valid():
            try:
                _send_email(
                    settings.email, run_summary, log_lines, settings.dashboard_url
                )
            except Exception as exc:
                logger.warning(
                    "Notification email channel raised unexpectedly: %s", exc
                )

        if settings.teams.is_valid():
            try:
                _send_teams(
                    settings.teams, run_summary, log_lines, settings.dashboard_url
                )
            except Exception as exc:
                logger.warning(
                    "Notification Teams channel raised unexpectedly: %s", exc
                )
    except Exception as exc:
        logger.warning("notify_run failed unexpectedly: %s", exc)
