"""Snowflake writer for app_logger.

Single module of plain functions. No classes, no abstractions.
Called by AppLogger.finish() when a Snowflake connection is provided.

On any failure, logs a warning and returns — never raises. The local
NDJSON file is the durable record; Snowflake is best-effort.
"""
from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Chunk size for batched log-line INSERTs.
# Each row binds 18 parameters; Snowflake caps a single statement at ~16,384
# bind parameters. 500 rows × 18 cols = 9,000 — well under the limit, with
# headroom for future column additions.
LOG_LINE_CHUNK_SIZE = 500

# Number of columns in the ETL_LOG_LINES INSERT (matches _LOG_LINE_COLUMNS).
_LOG_LINE_COL_COUNT = 18

# Column names match the LOGS.DATALAKE.ETL_LOG_LINES schema.
# DOCUMENTATION ONLY — not used at runtime. The INSERT SQL in
# _insert_log_lines and the tuple returned by _log_line_to_row must be
# kept in lockstep with this list. Kept here as the in-source schema
# reference for readers; if you reorder columns, update all three places.
_LOG_LINE_COLUMNS = (
    "RUN_ID", "LINE_NUMBER", "TS", "LEVEL", "APP", "JOB", "EVENT",
    "MESSAGE", "LOGGER", "STEP", "STATUS", "DURATION_S",
    "ROWS", "ROWS_FAILED", "ERROR_TYPE", "ERROR_DETAIL", "STACK_TRACE",
    "EXTRA_FIELDS",
)

# Fields from the log line dict that map directly to columns above.
# Anything else goes into the EXTRA_FIELDS VARIANT.
_KNOWN_LINE_FIELDS = frozenset({
    "run_id", "ts", "level", "app", "job", "event",
    "message", "logger", "step", "status", "duration_s",
    "rows", "rows_failed", "error_type", "error_detail", "stack_trace",
    # Fields we strip but don't map to columns:
    "schema_version", "host", "pid", "module", "func", "line",
})


def flush_to_snowflake(
    connection: Any,
    run_summary: dict[str, Any],
    log_lines: list[dict[str, Any]],
) -> None:
    """Write run summary + log lines to Snowflake.

    Called by AppLogger.finish() when snowflake_connection is provided.
    Catches every exception — never raises. A Snowflake outage must not
    break an ETL run.

    Args:
        connection: An open snowflake.connector connection (caller-owned).
        run_summary: dict from AppLogger._build_run_summary().
        log_lines: list of dicts (parsed from the buffered NDJSON strings).
    """
    try:
        _insert_run_summary(connection, run_summary)
        _insert_log_lines(connection, log_lines)
    except Exception as exc:
        logger.warning(
            "Snowflake log flush failed (run_id=%s): %s",
            run_summary.get("run_id", "?"),
            exc,
        )


def _insert_run_summary(connection: Any, summary: dict[str, Any]) -> None:
    """Insert a single row into LOGS.DATALAKE.ETL_RUN_SUMMARIES."""
    # NOTE: "ROWS" is a Snowflake reserved keyword and must be quoted.
    # "ROWS_FAILED" is quoted for symmetry with the DDL.
    # Use INSERT … SELECT (not VALUES) so PARSE_JSON() is allowed.
    # Snowflake rejects function calls inside an INSERT … VALUES (…) clause
    # ("Invalid expression [PARSE_JSON(…)] in VALUES clause"). This is a
    # single-row execute() so the connector's executemany-rewrite path is
    # not involved.
    sql = """
        INSERT INTO LOGS.DATALAKE.ETL_RUN_SUMMARIES (
            RUN_ID, APP, JOB, STATUS, STARTED_AT, ENDED_AT, DURATION_S,
            STEPS_TOTAL, STEPS_SUCCESS, STEPS_FAILED, STEPS_PARTIAL,
            "ROWS", "ROWS_FAILED", ERROR_COUNT, WARNING_COUNT, FAILED_STEPS,
            HOST, PID, LOG_FILE
        )
        SELECT
            %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s,
            %s, %s, %s, %s, PARSE_JSON(%s),
            %s, %s, %s
    """
    failed_steps_json = json.dumps(summary.get("failed_steps", []), default=str)
    params = (
        summary["run_id"],
        summary["app"],
        summary["job"],
        summary["status"],
        summary["started_at"],
        summary["ended_at"],
        summary["duration_s"],
        summary.get("steps_total"),
        summary.get("steps_success"),
        summary.get("steps_failed"),
        summary.get("steps_partial"),
        summary.get("rows"),
        summary.get("rows_failed"),
        summary.get("error_count", 0),
        summary.get("warning_count", 0),
        failed_steps_json,
        summary.get("host", ""),
        summary.get("pid", 0),
        summary.get("log_file", ""),
    )
    cursor = connection.cursor()
    try:
        cursor.execute(sql, params)
    finally:
        cursor.close()


def _insert_log_lines(connection: Any, lines: list[dict[str, Any]]) -> None:
    """Batch-insert log lines into LOGS.DATALAKE.ETL_LOG_LINES.

    SQL pattern: INSERT … SELECT cols, PARSE_JSON(extras) FROM (VALUES (…), (…), …) AS v.
    PARSE_JSON has to live in the SELECT — Snowflake rejects function calls
    inside a VALUES clause. The VALUES-in-FROM clause holds only bind
    parameters, which lets us batch many rows in a single execute() call
    without falling into the connector's executemany rewrite path (which
    cannot handle INSERT … SELECT statements and raises 252001).

    Each row binds _LOG_LINE_COL_COUNT (18) parameters; Snowflake caps a
    single statement at ~16,384 bind parameters, so we chunk at
    LOG_LINE_CHUNK_SIZE rows.
    """
    if not lines:
        return

    cursor = connection.cursor()
    try:
        for chunk_start in range(0, len(lines), LOG_LINE_CHUNK_SIZE):
            chunk = lines[chunk_start : chunk_start + LOG_LINE_CHUNK_SIZE]
            sql = _build_log_lines_sql(len(chunk))
            flat_params: list[Any] = []
            for i, line in enumerate(chunk):
                flat_params.extend(
                    _log_line_to_row(line, line_number=chunk_start + i + 1)
                )
            cursor.execute(sql, flat_params)
    finally:
        cursor.close()


def _build_log_lines_sql(row_count: int) -> str:
    """Build a multi-row INSERT … SELECT … FROM (VALUES …) statement.

    The number of (?,?,…,?) groups is structural (driven by row_count),
    not user data — no SQL injection surface. All actual values are
    parameter-bound.
    """
    row_placeholder = "(" + ",".join(["%s"] * _LOG_LINE_COL_COUNT) + ")"
    values_block = ",".join([row_placeholder] * row_count)
    return f"""
        INSERT INTO LOGS.DATALAKE.ETL_LOG_LINES (
            RUN_ID, LINE_NUMBER, TS, LEVEL, APP, JOB, EVENT,
            MESSAGE, LOGGER, STEP, STATUS, DURATION_S,
            "ROWS", "ROWS_FAILED", ERROR_TYPE, ERROR_DETAIL, STACK_TRACE,
            EXTRA_FIELDS
        )
        SELECT
            c1, c2, c3, c4, c5, c6, c7,
            c8, c9, c10, c11, c12,
            c13, c14, c15, c16, c17,
            PARSE_JSON(c18)
        FROM (VALUES {values_block}) AS v(
            c1, c2, c3, c4, c5, c6, c7,
            c8, c9, c10, c11, c12,
            c13, c14, c15, c16, c17, c18
        )
    """


def _log_line_to_row(line: dict[str, Any], line_number: int) -> tuple:
    """Convert a log-line dict into a tuple of column values.

    Unknown fields (anything not in _KNOWN_LINE_FIELDS) are JSON-serialized
    into the EXTRA_FIELDS column so VARIANT queries remain possible.
    """
    extra = {
        k: v
        for k, v in line.items()
        if k not in _KNOWN_LINE_FIELDS
    }
    extra_json = json.dumps(extra, default=str) if extra else None

    return (
        line.get("run_id", ""),
        line_number,
        line.get("ts"),
        line.get("level", ""),
        line.get("app", ""),
        line.get("job", ""),
        line.get("event", "LOG"),
        line.get("message", ""),
        line.get("logger", ""),
        line.get("step"),
        line.get("status"),
        line.get("duration_s"),
        line.get("rows"),
        line.get("rows_failed"),
        line.get("error_type"),
        line.get("error_detail"),
        line.get("stack_trace"),
        extra_json,
    )
