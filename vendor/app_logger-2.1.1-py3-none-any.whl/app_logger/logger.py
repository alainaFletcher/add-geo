"""
Standardized application logger for all scheduled Python jobs.

Usage::

    from app_logger import AppLogger

    def main():
        log = AppLogger("ETL_ICtoSnowflake", job="daily_full_load")
        log.start(trigger="cron", schedule="0 6 * * *")

        try:
            with log.step("extract_students", source="infinite_campus") as s:
                rows = extract()
                s.rows = len(rows)

            with log.step("load_students", table_name="STUDENTS") as s:
                loaded, failed = load(rows)
                s.rows = loaded
                s.rows_failed = failed

            # For steps with multiple sub-operations, use add_rows():
            with log.step("load_all_tables") as s:
                for table in tables:
                    count = load_table(table)
                    s.add_rows(count)
        finally:
            status = log.finish()
            sys.exit(0 if status in ("SUCCESS", "PARTIAL") else 1)
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import signal
import socket
import sys
import threading
import traceback
import re
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator

from .notifications import NotificationSettings, notify_run
from .purge import purge_old_index, purge_old_logs
from .redaction import redact_value, sanitize_error_message, should_redact_key
from .schema import SCHEMA_VERSION, Status
from .snowflake_writer import flush_to_snowflake

# ── Module-level constants ────────────────────────────────────────────────────

APP_VERSION: str = os.environ.get("APP_VERSION", "unknown")
HOST: str = socket.gethostname()
def _get_log_root() -> Path:
    """Resolve APP_LOG_ROOT at call time so late env-var changes take effect."""
    return Path(os.environ.get("APP_LOG_ROOT", "./logs"))

_SAFE_NAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")

# Status → log level for the synthetic RUN_END line emitted by finish().
# Kept as a module-level table so the relationship between run-outcome
# and event-severity is explicit and easy to audit. SKIPPED is a deliberate
# no-op outcome, not an error; it maps to INFO so it does not inflate
# error_count and does not trigger ERROR-level notifications.
_STATUS_TO_LEVEL: dict[str, int] = {
    "SUCCESS": logging.INFO,
    "PARTIAL": logging.WARNING,
    "SKIPPED": logging.INFO,
    "FAILED": logging.ERROR,
}

# ── fcntl import (POSIX file locking, once at module level) ──────────────────

try:
    import fcntl as _fcntl
except ImportError:
    _fcntl = None  # type: ignore[assignment]

# ── Optional orjson for fast serialization ────────────────────────────────────

try:
    import orjson

    def _json_serialize(obj: dict[str, Any]) -> str:
        return orjson.dumps(obj, default=str).decode()

except ImportError:

    def _json_serialize(obj: dict[str, Any]) -> str:
        return json.dumps(obj, default=str, ensure_ascii=False)


# ── Run ID ────────────────────────────────────────────────────────────────────


def generate_run_id(app: str) -> str:
    """
    Generate a unique run identifier.

    Format: ``{app-slug}-{YYYYMMDD}-{8-hex-chars}``
    Example: ``etl-ic2sf-20260303-a3f9b7c1``
    """
    date_str = datetime.now(timezone.utc).strftime("%Y%m%d")
    slug = app.lower().replace("_", "-")[:12]
    uid = uuid.uuid4().hex[:8]
    return f"{slug}-{date_str}-{uid}"


# ── Exit Codes ────────────────────────────────────────────────────────────────


class ExitCode:
    """Standard exit codes for scheduled applications."""

    SUCCESS: int = 0
    PARTIAL_SUCCESS: int = 0  # Job completed; true status in log metadata
    FAILED: int = 1
    CONFIG_ERROR: int = 10  # Avoids POSIX code 2 (argparse usage error)
    CONNECTION_ERROR: int = 11
    UNEXPECTED_ERROR: int = 99
    SIGTERM: int = 143  # 128 + 15 (POSIX convention)


# ── Deep redaction helper ─────────────────────────────────────────────────


def _redact_deep(val: Any, *, _depth: int = 0) -> Any:
    """Recursively redact secrets in nested structures (dicts, lists, strings)."""
    if _depth > 10:
        return val
    if isinstance(val, str):
        return redact_value(val)
    if isinstance(val, dict):
        return {
            k: "[REDACTED]" if should_redact_key(k) else _redact_deep(v, _depth=_depth + 1)
            for k, v in val.items()
        }
    if isinstance(val, (list, tuple)):
        return type(val)(_redact_deep(item, _depth=_depth + 1) for item in val)
    return val


# ── NDJSON Formatter ──────────────────────────────────────────────────────────


class _NDJSONFormatter(logging.Formatter):
    """Emits one JSON object per log record with secret redaction."""

    _SKIP: frozenset[str] = frozenset(
        {
            "msg",
            "args",
            "levelname",
            "levelno",
            "pathname",
            "filename",
            "exc_info",
            "exc_text",
            "stack_info",
            "created",
            "msecs",
            "relativeCreated",
            "thread",
            "threadName",
            "processName",
            "name",
            "message",
            "taskName",
            # Already extracted under renamed keys:
            "lineno",
            "funcName",
            "module",
            "process",
        }
    )

    # Tier 1+2 fields that must not be overridden by extra kwargs
    _RESERVED: frozenset[str] = frozenset(
        {
            "ts",
            "level",
            "schema_version",
            "logger",
            "message",
            "module",
            "func",
            "line",
            "host",
            "pid",
        }
    )

    def format(self, record: logging.LogRecord) -> str:
        record.message = record.getMessage()

        # Save exc_info — this record is shared across all handlers,
        # and we must restore it so later handlers (console) still see it.
        saved_exc_info = record.exc_info
        saved_exc_text = record.exc_text

        try:
            entry: dict[str, Any] = {
                "ts": (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat(timespec="milliseconds")
                    .replace("+00:00", "Z")
                ),
                "level": record.levelname,
                "schema_version": SCHEMA_VERSION,
                "logger": record.name,
                "message": redact_value(record.message),
                "module": record.module,
                "func": record.funcName,
                "line": record.lineno,
                "host": HOST,
                "pid": record.process,
            }

            # Merge extra/context fields (skip reserved keys to prevent injection)
            for key, val in record.__dict__.items():
                if key in self._SKIP or key.startswith("_") or key in self._RESERVED:
                    continue
                if key not in entry:
                    if should_redact_key(key):
                        val = "[REDACTED]"
                    else:
                        val = _redact_deep(val)
                    entry[key] = val

            # Serialize exception as stack_trace string
            if record.exc_info and record.exc_info[0] is not None:
                limit = int(os.environ.get("LOG_TRACEBACK_LIMIT", "0")) or None
                tb_str = "".join(
                    traceback.format_exception(*record.exc_info, limit=limit)
                )
                # Truncate huge tracebacks (recursive errors can exceed 100KB)
                if len(tb_str) > 50_000:
                    tb_str = (
                        tb_str[:25_000] + "\n...[TRUNCATED]...\n" + tb_str[-25_000:]
                    )
                entry["stack_trace"] = sanitize_error_message(tb_str)
                # Clear for THIS format call only (prevents default Formatter
                # from appending traceback to our JSON output)
                record.exc_info = None
                record.exc_text = None

            try:
                return _json_serialize(entry)
            except (ValueError, RecursionError):
                # Circular reference or non-serializable extra field; emit safe subset
                safe = {
                    k: entry[k]
                    for k in (
                        "ts",
                        "level",
                        "schema_version",
                        "logger",
                        "message",
                        "host",
                        "pid",
                        "run_id",
                        "app",
                        "job",
                        "event",
                    )
                    if k in entry
                }
                safe["_serialization_error"] = True
                return json.dumps(safe, default=str, ensure_ascii=False)
        finally:
            # Restore so subsequent handlers (console, error-file) see exc_info
            record.exc_info = saved_exc_info
            record.exc_text = saved_exc_text


# ── Console Formatter (human-readable) ────────────────────────────────────────


class _ConsoleFormatter(logging.Formatter):
    """Human-readable console format with UTC timestamps and secret redaction."""

    FMT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    DFT = "%Y-%m-%d %H:%M:%S"

    def __init__(self) -> None:
        super().__init__(fmt=self.FMT, datefmt=self.DFT)

    def format(self, record: logging.LogRecord) -> str:
        """Apply redaction to the formatted output."""
        output = super().format(record)
        return redact_value(output)

    def formatTime(
        self, record: logging.LogRecord, datefmt: str | None = None
    ) -> str:
        """Override to use UTC timestamps matching the JSON file timestamps."""
        dt = datetime.fromtimestamp(record.created, tz=timezone.utc)
        return dt.strftime(datefmt or self.DFT)


# ── Buffer Handler (captures formatted lines for downstream consumers) ────────


class _BufferHandler(logging.Handler):
    """Captures formatted JSON log lines into an in-memory list.

    Used by AppLogger.finish() to feed the snowflake_writer and notifications
    modules without re-reading the log file. Stores serialized JSON strings;
    callers parse to dicts at flush time (one parse pass per run, not per line).
    """

    def __init__(self, formatter: logging.Formatter) -> None:
        super().__init__(level=logging.DEBUG)
        self.setFormatter(formatter)
        self._buffer: list[str] = []
        self._lock = threading.Lock()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            line = self.format(record)
            with self._lock:
                self._buffer.append(line)
        except Exception:
            self.handleError(record)

    def get_buffer(self) -> list[str]:
        """Return a copy of the buffer (list of JSON strings)."""
        with self._lock:
            return list(self._buffer)

    def clear(self) -> None:
        with self._lock:
            self._buffer.clear()


# ── Context Filter ────────────────────────────────────────────────────────────


class _ContextFilter(logging.Filter):
    """Injects run_id, app, job, step, and event into every log record.

    Also counts ERROR and WARNING records as they pass through, so that
    ``AppLogger.finish()`` can report totals even when no step failed.
    """

    def __init__(self, app: str, run_id: str, job: str) -> None:
        super().__init__()
        self._fields = {"app": app, "run_id": run_id, "job": job}
        self._local = threading.local()
        self._counter_lock = threading.Lock()
        self.error_count: int = 0
        self.warning_count: int = 0

    def set_step(self, step: str | None) -> None:
        self._local.step = step

    def filter(self, record: logging.LogRecord) -> bool:
        for k, v in self._fields.items():
            setattr(record, k, v)
        # Only set step from thread-local context if not already provided
        # via extra kwargs (e.g. metric() passes step explicitly).
        if not getattr(record, "step", None):
            record.step = getattr(self._local, "step", None)  # type: ignore[attr-defined]
        # Default event to LOG for sub-module log lines that don't set it
        if not hasattr(record, "event"):
            record.event = "LOG"  # type: ignore[attr-defined]
        # Count errors and warnings for the run summary (thread-safe)
        with self._counter_lock:
            if record.levelno >= logging.ERROR:
                self.error_count += 1
            elif record.levelno >= logging.WARNING:
                self.warning_count += 1
        return True


# ── Step Result ───────────────────────────────────────────────────────────────


class StepResult:
    """
    Returned as the context variable from :meth:`AppLogger.step`.

    Example::

        with log.step("load_students") as s:
            s.rows = 100
            s.metadata["table_name"] = "STUDENTS"

        # For steps with multiple sub-operations:
        with log.step("load_all_tables") as s:
            for table in tables:
                loaded = load_table(table)
                s.add_rows(loaded)
    """

    __slots__ = (
        "name",
        "rows",
        "rows_failed",
        "status",
        "error_summary",
        "error_type",
        "duration_s",
        "metadata",
    )

    def __init__(self, name: str) -> None:
        self.name: str = name
        self.rows: int | None = None
        self.rows_failed: int | None = None
        self.status: Status = "SUCCESS"
        self.error_summary: str = ""
        self.error_type: str = ""
        self.duration_s: float = 0.0
        self.metadata: dict[str, Any] = {}

    def add_rows(self, count: int, *, failed: int = 0) -> None:
        """Accumulate row counts from sub-operations.

        Handles the ``None``-to-``int`` transition automatically, so callers
        need not check whether ``rows`` has been set yet.

        Both ``count`` and ``failed`` must be non-negative integers;
        passing ``None`` will raise ``TypeError``.
        """
        if count < 0:
            raise ValueError(f"add_rows() count must be >= 0, got {count}")
        if failed < 0:
            raise ValueError(f"add_rows() failed must be >= 0, got {failed}")
        self.rows = (0 if self.rows is None else self.rows) + count
        self.rows_failed = (0 if self.rows_failed is None else self.rows_failed) + failed


# ── AppLogger ─────────────────────────────────────────────────────────────────


class AppLogger:
    """
    Standardized logger for all scheduled applications.

    Guarantees:

    - ``RUN_START`` emitted on :meth:`start`
    - ``RUN_END`` emitted on :meth:`finish` or on process exit (via atexit)
    - ``STEP_START``/``STEP_END`` emitted automatically by :meth:`step`
    - All log lines include: ts, level, run_id, app, job, event, host, pid
    - JSON to file; human-readable text to console

    Args:
        app:                  Stable application identifier (e.g. ``"ETL_ICtoSnowflake"``).
        job:                  Job name within the app (e.g. ``"daily_full_load"``).
        log_root:             Override ``APP_LOG_ROOT`` for this instance.
        run_id:               Explicit run ID; auto-generated if omitted.
        console_level:        Minimum level for console output (default ``INFO``).
        file_level:           Minimum level for file output (default ``DEBUG``).
        suppress_libraries:   Silence noisy third-party loggers (default ``True``).
        configure_root_logger: Attach NDJSON handlers and context filter to the
                              Python root logger so that sub-modules using
                              ``logging.getLogger(__name__)`` automatically produce
                              structured JSON output (default ``True``).
        purge_on_init:        Run log and index purge at startup (default ``False``).
    """

    def __init__(
        self,
        app: str,
        job: str,
        *,
        log_root: Path | str | None = None,
        run_id: str | None = None,
        console_level: int = logging.INFO,
        file_level: int = logging.DEBUG,
        suppress_libraries: bool = True,
        configure_root_logger: bool = True,
        purge_on_init: bool = False,
        snowflake_connection: Any = None,
        notify: bool = False,
    ) -> None:
        if not _SAFE_NAME_RE.match(app):
            raise ValueError(
                f"Invalid app name {app!r}: must match [A-Za-z0-9._-]+"
            )
        if not _SAFE_NAME_RE.match(job):
            raise ValueError(
                f"Invalid job name {job!r}: must match [A-Za-z0-9._-]+"
            )
        self.app = app
        self.job = job
        self.run_id = run_id or generate_run_id(app)

        self._root: Path = Path(log_root or _get_log_root())
        self._steps: list[StepResult] = []
        self._started: datetime | None = None
        self._finished: bool = False
        self._last_status: Status = "FAILED"
        self._snowflake_connection = snowflake_connection
        self._notify_enabled = notify
        if notify:
            self._notification_settings: NotificationSettings | None = NotificationSettings.from_env()
        else:
            self._notification_settings = None

        self._filter = _ContextFilter(app, self.run_id, job)
        self._log_path, self._err_path = self._build_log_paths()
        self._logger = self._configure_logging(
            console_level, file_level, configure_root_logger
        )

        if suppress_libraries:
            self._suppress_noisy_libraries()

        if purge_on_init:
            try:
                purge_old_logs(self._root, self.app)
                purge_old_index(self._root)
            except Exception:
                # Purge failure must never prevent application startup
                self._logger.warning(
                    "Log purge failed at init", exc_info=True
                )

        atexit.register(self._atexit_handler)

        # Emit RUN_END on SIGTERM (Docker graceful shutdown).
        # signal.signal() can only be called from the main thread.
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGTERM, self._sigterm_handler)

    # ── Public API ─────────────────────────────────────────────────────────

    def start(
        self,
        trigger: str = "cron",
        schedule: str = "",
        run_type: str = "scheduled",
        **extra: Any,
    ) -> None:
        """Emit ``RUN_START``. Call once at the top of ``main()``."""
        if self._started is not None:
            raise RuntimeError("start() already called; cannot call twice")
        self._started = datetime.now(timezone.utc)
        self._logger.info(
            "Job started",
            extra={
                "event": "RUN_START",
                "trigger": trigger,
                "schedule": schedule,
                "run_type": run_type,
                "app_version": APP_VERSION,
                **extra,
            },
        )

    @contextmanager
    def step(
        self,
        name: str,
        *,
        fatal: bool = True,
        **start_fields: Any,
    ) -> Generator[StepResult, None, None]:
        """
        Context manager for a named pipeline step.

        Automatically emits ``STEP_START`` and ``STEP_END``
        (``SUCCESS``/``PARTIAL``/``FAILED``).  Accumulates rows/rows_failed
        into job totals.

        Args:
            name:   Step identifier (e.g. ``"load_students"``).
            fatal:  If ``False``, exceptions are caught and logged but not
                    re-raised.  The step is marked ``FAILED`` but the run
                    continues.
            **start_fields: Extra fields to include on both ``STEP_START``
                            and ``STEP_END`` events.
        """
        result = StepResult(name)
        self._filter.set_step(name)
        t0 = datetime.now(timezone.utc)

        self._logger.info(
            f"Starting step: {name}",
            extra={"event": "STEP_START", "step": name, **start_fields},
        )

        try:
            yield result
            result.duration_s = (datetime.now(timezone.utc) - t0).total_seconds()
            # Respect manually-set FAILED or SKIPPED status (e.g., when
            # caller sets step.status = "SKIPPED" for no-op steps)
            if result.status not in ("FAILED", "SKIPPED"):
                result.status = "PARTIAL" if result.rows_failed is not None and result.rows_failed > 0 else "SUCCESS"
            if result.status == "FAILED":
                level = logging.ERROR
            elif result.status == "PARTIAL":
                level = logging.WARNING
            else:
                level = logging.INFO
            end_extra: dict[str, Any] = {
                "event": "STEP_END",
                "step": name,
                "status": result.status,
                "duration_s": round(result.duration_s, 3),
                "rows": result.rows,
                "rows_failed": result.rows_failed,
                **start_fields,
            }
            if result.metadata:
                end_extra.update(result.metadata)
            self._logger.log(
                level,
                f"Completed step: {name}",
                extra=end_extra,
            )
        except Exception as exc:
            result.duration_s = (datetime.now(timezone.utc) - t0).total_seconds()
            result.status = "FAILED"
            result.error_summary = sanitize_error_message(str(exc)[:500])
            result.error_type = type(exc).__name__

            self._logger.error(
                f"Step failed: {name}: {type(exc).__name__}",
                exc_info=True,
                extra={
                    "event": "ERROR",
                    "step": name,
                    "error_type": type(exc).__name__,
                    "error_detail": sanitize_error_message(str(exc)[:500]),
                    **start_fields,
                },
            )
            self._logger.warning(
                f"Step failed: {name}",
                extra={
                    "event": "STEP_END",
                    "step": name,
                    "status": "FAILED",
                    "duration_s": round(result.duration_s, 3),
                    "rows": result.rows,
                    "rows_failed": result.rows_failed,
                    **start_fields,
                },
            )
            if fatal:
                raise
        finally:
            self._steps.append(result)
            self._filter.set_step(None)

    def finish(self, *, override_status: Status | None = None) -> Status:
        """
        Compute final status, emit ``RUN_END``, write run index.

        Returns the computed status string.  Call explicitly at the end of
        ``main()``.  The atexit handler covers crash cases.
        """
        if self._finished:
            return self._last_status
        if override_status is not None:
            from typing import get_args
            _valid = get_args(Status)
            if override_status not in _valid:
                raise ValueError(
                    f"Invalid override_status {override_status!r}: must be one of {_valid}"
                )
        self._finished = True

        ended_at = datetime.now(timezone.utc)
        started_at = self._started or ended_at
        duration = (ended_at - started_at).total_seconds()

        n_failed = sum(1 for s in self._steps if s.status == "FAILED")
        n_partial = sum(1 for s in self._steps if s.status == "PARTIAL")
        _any_rows = any(s.rows is not None for s in self._steps)
        _any_failed = any(s.rows_failed is not None for s in self._steps)
        total_rows: int | None = (
            sum(s.rows if s.rows is not None else 0 for s in self._steps)
            if _any_rows else None
        )
        failed_rows: int | None = (
            sum(s.rows_failed if s.rows_failed is not None else 0 for s in self._steps)
            if _any_failed else None
        )

        if override_status is not None:
            status: Status = override_status
        elif not self._steps:
            status = "FAILED" if self._started is None else "SUCCESS"
        elif n_failed > 0 and n_failed == len(self._steps):
            status = "FAILED"
        elif n_failed > 0 or n_partial > 0 or (failed_rows is not None and failed_rows > 0):
            status = "PARTIAL"
        else:
            status = "SUCCESS"

        self._last_status = status
        # Default to ERROR for unknown statuses so a future Status literal
        # added without updating this table fails loudly rather than silently
        # downgrading severity.
        level = _STATUS_TO_LEVEL.get(status, logging.ERROR)

        self._logger.log(
            level,
            f"Job completed with status {status}",
            extra={
                "event": "RUN_END",
                "status": status,
                "duration_s": round(duration, 3),
                "steps_total": len(self._steps),
                "steps_success": sum(
                    1 for s in self._steps if s.status == "SUCCESS"
                ),
                "steps_failed": n_failed,
                "steps_partial": n_partial,
                "rows": total_rows,
                "rows_failed": failed_rows,
                "error_count": self._filter.error_count,
                "warning_count": self._filter.warning_count,
                "started_at": started_at.isoformat(timespec="milliseconds").replace(
                    "+00:00", "Z"
                ),
            },
        )

        self._append_run_index(
            status, started_at, ended_at, duration,
            total_rows, failed_rows, n_failed, n_partial,
        )

        # Snowflake dual-write (best-effort; never raises)
        if self._snowflake_connection is not None:
            try:
                summary = self._build_run_summary(
                    status, started_at, ended_at, duration,
                    total_rows, failed_rows, n_failed, n_partial,
                )
                buffered = self._buffer_handler.get_buffer()
                log_lines: list[dict[str, Any]] = []
                for raw in buffered:
                    try:
                        log_lines.append(json.loads(raw))
                    except json.JSONDecodeError:
                        continue
                flush_to_snowflake(self._snowflake_connection, summary, log_lines)
            except Exception:
                # Defense in depth — flush_to_snowflake already swallows,
                # but we wrap again so a parsing error here cannot propagate.
                self._logger.warning(
                    "Unexpected error preparing Snowflake flush", exc_info=True
                )

        # Notifications dispatch (best-effort; never raises)
        if self._notify_enabled and self._notification_settings is not None:
            try:
                summary_for_notify = self._build_run_summary(
                    status, started_at, ended_at, duration,
                    total_rows, failed_rows, n_failed, n_partial,
                )
                buffered = self._buffer_handler.get_buffer()
                lines_for_notify: list[dict[str, Any]] = []
                for raw in buffered:
                    try:
                        lines_for_notify.append(json.loads(raw))
                    except json.JSONDecodeError:
                        continue
                notify_run(
                    summary_for_notify, lines_for_notify, self._notification_settings
                )
            except Exception:
                self._logger.warning(
                    "Unexpected error preparing notifications", exc_info=True
                )

        self._flush_handlers()
        return status

    def debug(self, msg: str, **extra: Any) -> None:
        """Emit a DEBUG-level ``LOG`` event."""
        self._logger.debug(msg, extra={"event": "LOG", **extra})

    def info(self, msg: str, **extra: Any) -> None:
        """Emit an INFO-level ``LOG`` event."""
        self._logger.info(msg, extra={"event": "LOG", **extra})

    def warning(self, msg: str, **extra: Any) -> None:
        """Emit a WARNING-level ``LOG`` event."""
        self._logger.warning(msg, extra={"event": "LOG", **extra})

    def error(self, msg: str, exc_info: bool = False, **extra: Any) -> None:
        """Emit an ERROR-level ``ERROR`` event."""
        self._logger.error(msg, exc_info=exc_info, extra={"event": "ERROR", **extra})

    def exception(self, msg: str, **extra: Any) -> None:
        """Log an ERROR with traceback.  Call from inside an ``except`` block."""
        self._logger.exception(msg, extra={"event": "ERROR", **extra})

    def metric(
        self, step: str, rows: int, rows_failed: int = 0, **extra: Any
    ) -> None:
        """Progress checkpoint for long-running steps."""
        self._logger.info(
            "Progress checkpoint",
            extra={
                "event": "METRIC",
                "step": step,
                "rows": rows,
                "rows_failed": rows_failed,
                **extra,
            },
        )

    # ── Internal Helpers ───────────────────────────────────────────────────

    def _build_log_paths(self) -> tuple[Path, Path]:
        """Create the app log directory and return (main_path, error_path)."""
        app_dir = self._root / self.app
        app_dir.mkdir(parents=True, exist_ok=True, mode=0o750)
        date_str = datetime.now(timezone.utc).strftime("%Y%m%d")
        main_path = app_dir / f"{self.job}_{date_str}.log"
        err_path = app_dir / f"{self.job}_errors_{date_str}.log"
        return main_path, err_path

    def _configure_logging(
        self,
        console_level: int,
        file_level: int,
        configure_root_logger: bool,
    ) -> logging.Logger:
        """Set up the app-specific logger and optionally the root logger."""
        logger = logging.getLogger(self.app)
        logger.setLevel(logging.DEBUG)
        logger.propagate = False

        # Remove pre-existing handlers/filters (prevents duplication)
        for h in logger.handlers[:]:
            h.close()
            logger.removeHandler(h)
        for f in logger.filters[:]:
            logger.removeFilter(f)

        logger.addFilter(self._filter)

        ndjson = _NDJSONFormatter()

        # File handler -- all levels, JSON
        fh = logging.FileHandler(self._log_path, encoding="utf-8")
        fh.setLevel(file_level)
        fh.setFormatter(ndjson)
        logger.addHandler(fh)

        # Error-only file handler
        eh = logging.FileHandler(self._err_path, encoding="utf-8")
        eh.setLevel(logging.ERROR)
        eh.setFormatter(ndjson)
        logger.addHandler(eh)

        # Console handler -- JSON in containers, human-readable in dev
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(console_level)
        if os.environ.get("CONSOLE_FORMAT", "text").lower() == "json":
            ch.setFormatter(ndjson)
        else:
            ch.setFormatter(_ConsoleFormatter())
        logger.addHandler(ch)

        # Buffer handler -- captures NDJSON lines in memory for Snowflake/notifications.
        # No handler-level filter: the logger-level filter (above) already runs for
        # records emitted on this logger, and on the root logger the filter is
        # attached to the file handlers that run before this one — so the context
        # attrs (app/run_id/job/event) are already set on the record by the time
        # the buffer handler emits. Adding the filter here would double-count
        # error_count / warning_count.
        self._buffer_handler = _BufferHandler(ndjson)
        logger.addHandler(self._buffer_handler)

        # ── Root logger attachment (namespace gap fix) ─────────────────────
        # Sub-modules use logging.getLogger(__name__) which produces names
        # like "sites.amplify.automation" that don't inherit from the
        # app-specific logger.  By attaching the NDJSON file handlers and
        # context filter to the root logger, ALL loggers in the process
        # inherit structured output with run_id/app/job/event fields.
        #
        # IMPORTANT: Filters on a logger only run for records emitted
        # directly by that logger, NOT for records propagating from child
        # loggers.  To ensure the context filter injects run_id/app/job
        # into ALL propagated records, we attach the filter to each
        # *handler* on the root logger (handler filters run on every
        # record the handler processes).
        if configure_root_logger:
            root = logging.getLogger()
            # Ensure root level allows DEBUG through (handlers filter further)
            root.setLevel(logging.DEBUG)

            # Remove any prior AppLogger-installed root handlers to prevent
            # duplication on re-instantiation.  We tag our handlers so we
            # can identify them.
            for h in root.handlers[:]:
                if getattr(h, "_app_logger_managed", False):
                    h.close()
                    root.removeHandler(h)

            # File handler for root (same NDJSON file)
            root_fh = logging.FileHandler(self._log_path, encoding="utf-8")
            root_fh.setLevel(file_level)
            root_fh.setFormatter(ndjson)
            root_fh.addFilter(self._filter)
            root_fh._app_logger_managed = True  # type: ignore[attr-defined]
            root.addHandler(root_fh)

            # Error-only file handler for root
            root_eh = logging.FileHandler(self._err_path, encoding="utf-8")
            root_eh.setLevel(logging.ERROR)
            root_eh.setFormatter(ndjson)
            root_eh.addFilter(self._filter)
            root_eh._app_logger_managed = True  # type: ignore[attr-defined]
            root.addHandler(root_eh)

            # Buffer handler also attached to root so sub-module records are captured.
            # The handler instance is shared; thread-safe via internal lock.
            # Tag with _app_logger_managed so the existing cleanup loop above
            # (lines that scan root.handlers and remove tagged handlers on
            # re-instantiation) catches it too.
            self._buffer_handler._app_logger_managed = True  # type: ignore[attr-defined]
            root.addHandler(self._buffer_handler)

            self._root_logger_configured = True
        else:
            self._root_logger_configured = False

        return logger

    def _suppress_noisy_libraries(self) -> None:
        """Set third-party library loggers to WARNING to reduce noise."""
        noisy = [
            "urllib3",
            "urllib3.connectionpool",
            "requests",
            "httpx",
            "snowflake",
            "snowflake.connector",
            "botocore",
            "boto3",
            "s3transfer",
            "paramiko",
            "paramiko.transport",
            "playwright",
            "asyncio",
            "pyodbc",
            "sqlalchemy",
            "sqlalchemy.engine",
            "sqlalchemy.pool",
            "matplotlib",
            "PIL",
            "werkzeug",
        ]
        for lib in noisy:
            logging.getLogger(lib).setLevel(logging.WARNING)

    def _build_run_summary(
        self,
        status: Status,
        started_at: datetime,
        ended_at: datetime,
        duration: float,
        total_rows: int | None,
        failed_rows: int | None,
        n_failed: int,
        n_partial: int,
    ) -> dict[str, Any]:
        """Build the RUN_SUMMARY dict shared by the index file, Snowflake writer,
        and notification dispatcher. Single source of truth."""
        failed_steps = [
            {
                "step": s.name,
                "status": s.status,
                "error": sanitize_error_message(s.error_summary[:500]),
                "error_type": s.error_type,
            }
            for s in self._steps
            if s.status in ("FAILED", "PARTIAL")
        ]

        return {
            "event": "RUN_SUMMARY",
            "schema_version": SCHEMA_VERSION,
            "app": self.app,
            "job": self.job,
            "run_id": self.run_id,
            "status": status,
            "started_at": started_at.isoformat(timespec="milliseconds").replace(
                "+00:00", "Z"
            ),
            "ended_at": ended_at.isoformat(timespec="milliseconds").replace(
                "+00:00", "Z"
            ),
            "duration_s": round(duration, 3),
            "steps_total": len(self._steps),
            "steps_success": sum(
                1 for s in self._steps if s.status == "SUCCESS"
            ),
            "steps_failed": n_failed,
            "steps_partial": n_partial,
            "rows": total_rows if total_rows is not None else 0,
            "rows_failed": failed_rows if failed_rows is not None else 0,
            "error_count": self._filter.error_count,
            "warning_count": self._filter.warning_count,
            "failed_steps": failed_steps,
            "host": HOST,
            "pid": os.getpid(),
            "log_file": str(self._log_path.relative_to(self._root)),
        }

    def _append_run_index(
        self,
        status: Status,
        started_at: datetime,
        ended_at: datetime,
        duration: float,
        total_rows: int | None,
        failed_rows: int | None,
        n_failed: int,
        n_partial: int,
    ) -> None:
        """Append the run summary to the monthly index file."""
        summary = self._build_run_summary(
            status, started_at, ended_at, duration,
            total_rows, failed_rows, n_failed, n_partial,
        )
        month_str = ended_at.strftime("%Y%m")
        index_path = self._root / "_index" / f"runs_{month_str}.jsonl"
        index_path.parent.mkdir(parents=True, exist_ok=True, mode=0o750)

        line = json.dumps(summary, default=str) + "\n"

        try:
            with index_path.open("a", encoding="utf-8") as fh:
                if _fcntl:
                    try:
                        _fcntl.flock(fh.fileno(), _fcntl.LOCK_EX)
                    except OSError:
                        print(
                            "WARNING: flock failed on run index",
                            file=sys.stderr,
                        )
                try:
                    fh.write(line)
                    fh.flush()
                finally:
                    if _fcntl:
                        try:
                            _fcntl.flock(fh.fileno(), _fcntl.LOCK_UN)
                        except OSError:
                            pass
        except OSError as exc:
            self._logger.warning("Could not write to run index: %s", exc)

    def _flush_handlers(self) -> None:
        """Flush all file handlers.  Does NOT close handlers or stdout."""
        for h in self._logger.handlers:
            h.flush()
        # Also flush root-logger handlers if we manage them
        if self._root_logger_configured:
            root = logging.getLogger()
            for h in root.handlers:
                if getattr(h, "_app_logger_managed", False):
                    h.flush()

    def _atexit_handler(self) -> None:
        """Ensure RUN_END is emitted even if finish() was never called."""
        if not self._finished:
            if self._started is None:
                self.finish(override_status="FAILED")
            else:
                # Let finish() compute status from step results
                self.finish()

    def _sigterm_handler(self, signum: int, frame: Any) -> None:
        """Emit RUN_END before process exits on SIGTERM."""
        if not self._finished:
            self.finish(override_status="FAILED")
        sys.exit(143)
