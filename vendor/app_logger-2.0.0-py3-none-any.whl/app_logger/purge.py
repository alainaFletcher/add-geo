"""
Log retention and purge utilities.

Provides functions to delete log files and index files that exceed the
configured retention period.  Dates are parsed from filenames (not mtime)
for deterministic, timezone-safe behavior.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from pathlib import Path


def purge_old_logs(
    log_dir: Path,
    app_name: str,
    main_days: int = 90,
    error_days: int = 180,
) -> None:
    """
    Remove log files older than the retention policy.

    Scoped to the specified app's subdirectory only -- one app must not
    delete another's logs.  Parses dates from filenames (not mtime) for
    deterministic behavior.

    Args:
        log_dir:    Root log directory (``APP_LOG_ROOT``).
        app_name:   Application name whose subdirectory to scan.
        main_days:  Retention for main log files (default 90).
        error_days: Retention for error-only log files (default 180).
    """
    app_dir = log_dir / app_name
    if not app_dir.is_dir():
        return

    now = datetime.now(tz=timezone.utc)
    date_pattern = re.compile(r"(\d{8})\.log$")

    for log_file in app_dir.glob("*.log"):
        is_error = "_errors_" in log_file.name
        cutoff = now - timedelta(days=error_days if is_error else main_days)

        match = date_pattern.search(log_file.name)
        if match:
            try:
                file_date = datetime.strptime(match.group(1), "%Y%m%d").replace(
                    tzinfo=timezone.utc
                )
            except ValueError:
                continue
        else:
            # Fall back to mtime if the filename doesn't contain a date
            try:
                file_date = datetime.fromtimestamp(
                    log_file.stat().st_mtime, tz=timezone.utc
                )
            except OSError:
                continue

        if file_date < cutoff:
            try:
                log_file.unlink()
            except OSError:
                pass  # best-effort; another process may have deleted it


def purge_old_index(log_dir: Path, max_days: int = 365) -> None:
    """
    Remove run index files older than the retention policy.

    Index files are monthly (``runs_YYYYMM.jsonl``).  A file is removed
    when the first day of its month is older than *max_days*.

    Args:
        log_dir:  Root log directory (``APP_LOG_ROOT``).
        max_days: Retention for index files (default 365).
    """
    index_dir = log_dir / "_index"
    if not index_dir.is_dir():
        return

    cutoff = datetime.now(tz=timezone.utc) - timedelta(days=max_days)
    month_pattern = re.compile(r"runs_(\d{6})\.jsonl$")

    for index_file in index_dir.glob("runs_*.jsonl"):
        match = month_pattern.search(index_file.name)
        if match:
            try:
                file_month = datetime.strptime(
                    match.group(1) + "01", "%Y%m%d"
                ).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
            if file_month < cutoff:
                try:
                    index_file.unlink()
                except OSError:
                    pass
