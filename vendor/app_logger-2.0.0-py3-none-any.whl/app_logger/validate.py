"""
Log validation CLI module for the app_logger package.

Reads an NDJSON log file and validates each line against the logging schema.
Runnable as::

    python -m app_logger.validate logfile.log [--check-secrets]

Checks performed:
    - Required Tier 1 fields present on every line
    - RUN_START / RUN_END pairing (every RUN_START has a matching RUN_END)
    - STEP_START / STEP_END pairing (every STEP_START has a matching STEP_END)
    - ``error_category`` is set on ERROR events
    - ``schema_version`` is present on every line
    - (optional) ``--check-secrets`` scans all string values for secret patterns

Exit codes:
    0  -- All lines valid, no violations
    1  -- One or more violations found
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .redaction import SECRET_PATTERNS, should_redact_key

# ── Tier 1 required fields ───────────────────────────────────────────────────

TIER1_REQUIRED: frozenset[str] = frozenset({
    "ts",
    "level",
    "schema_version",
    "run_id",
    "app",
    "job",
    "event",
    "message",
    "logger",
    "host",
    "pid",
})


# ── Violation tracking ───────────────────────────────────────────────────────


class Violation:
    """A single validation violation."""

    __slots__ = ("line_num", "description")

    def __init__(self, line_num: int, description: str) -> None:
        self.line_num = line_num
        self.description = description

    def __str__(self) -> str:
        return f"  Line {self.line_num}: {self.description}"


# ── Core validation ──────────────────────────────────────────────────────────


def validate_file(
    path: Path,
    *,
    check_secrets: bool = False,
) -> tuple[int, int, list[Violation]]:
    """Validate an NDJSON log file.

    Args:
        path:          Path to the NDJSON log file.
        check_secrets: If ``True``, scan all string values for secret patterns.

    Returns:
        A tuple of ``(total_lines, valid_lines, violations)``.
    """
    violations: list[Violation] = []
    total_lines = 0
    valid_lines = 0

    # Track lifecycle pairing per run_id
    # run_id -> True if RUN_START seen
    run_starts: dict[str, int] = {}  # run_id -> line number of RUN_START
    run_ends: set[str] = set()       # run_ids that have a RUN_END

    # step tracking: (run_id, step_name) -> line number of STEP_START
    step_starts: dict[tuple[str, str], int] = {}
    step_ends: set[tuple[str, str]] = set()

    with path.open(encoding="utf-8") as fh:
        for line_num, raw_line in enumerate(fh, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue

            total_lines += 1
            line_valid = True

            # Parse JSON
            try:
                entry: dict[str, Any] = json.loads(raw_line)
            except json.JSONDecodeError as exc:
                violations.append(Violation(line_num, f"Invalid JSON: {exc}"))
                continue

            if not isinstance(entry, dict):
                violations.append(
                    Violation(line_num, "Line is valid JSON but not an object")
                )
                continue

            # -- Check Tier 1 required fields --
            missing = TIER1_REQUIRED - entry.keys()
            if missing:
                violations.append(
                    Violation(
                        line_num,
                        f"Missing required field(s): {', '.join(sorted(missing))}",
                    )
                )
                line_valid = False

            # -- Check schema_version present (explicit check as required) --
            if "schema_version" not in entry:
                # Already caught above, but kept for explicitness
                pass

            # -- Lifecycle tracking --
            event = entry.get("event", "")
            run_id = entry.get("run_id", "")
            step_name = entry.get("step", "")

            if event == "RUN_START":
                run_starts[run_id] = line_num

            elif event == "RUN_END":
                run_ends.add(run_id)

            elif event == "STEP_START":
                step_key = (run_id, step_name)
                step_starts[step_key] = line_num

            elif event == "STEP_END":
                step_key = (run_id, step_name)
                step_ends.add(step_key)

            # -- error_category on ERROR events --
            if event == "ERROR" and "error_category" not in entry:
                violations.append(
                    Violation(
                        line_num,
                        "ERROR event missing 'error_category' field",
                    )
                )
                line_valid = False

            # -- Secret scanning --
            if check_secrets:
                secret_violations = _scan_for_secrets(entry, line_num)
                if secret_violations:
                    violations.extend(secret_violations)
                    line_valid = False

            if line_valid:
                valid_lines += 1

    # -- Post-scan: check lifecycle pairing --
    for run_id, start_line in run_starts.items():
        if run_id not in run_ends:
            violations.append(
                Violation(
                    start_line,
                    f"RUN_START for run_id '{run_id}' has no matching RUN_END",
                )
            )

    for step_key, start_line in step_starts.items():
        if step_key not in step_ends:
            run_id, step_name = step_key
            violations.append(
                Violation(
                    start_line,
                    f"STEP_START for step '{step_name}' (run_id '{run_id}') "
                    f"has no matching STEP_END",
                )
            )

    return total_lines, valid_lines, violations


def _scan_for_secrets(
    entry: dict[str, Any], line_num: int
) -> list[Violation]:
    """Scan all string values in a log entry for secret patterns."""
    found: list[Violation] = []

    for key, val in entry.items():
        # Check key names
        if should_redact_key(key):
            found.append(
                Violation(
                    line_num,
                    f"Key '{key}' matches a known secret key pattern",
                )
            )

        # Check string values against secret patterns
        if isinstance(val, str):
            for pattern in SECRET_PATTERNS:
                match = pattern.search(val)
                if match:
                    # Report the pattern name, not the matched value
                    found.append(
                        Violation(
                            line_num,
                            f"Value in field '{key}' matches secret pattern "
                            f"'{pattern.pattern[:40]}...'",
                        )
                    )
                    break  # one violation per field is enough

    return found


# ── CLI entry point ──────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for ``python -m app_logger.validate``.

    Args:
        argv: Command-line arguments (defaults to ``sys.argv[1:]``).

    Returns:
        Exit code: 0 if valid, 1 if violations found.
    """
    parser = argparse.ArgumentParser(
        prog="python -m app_logger.validate",
        description="Validate an NDJSON log file against the app_logger schema.",
    )
    parser.add_argument(
        "logfile",
        type=Path,
        help="Path to the NDJSON log file to validate.",
    )
    parser.add_argument(
        "--check-secrets",
        action="store_true",
        default=False,
        help="Scan all string values for secret patterns.",
    )

    args = parser.parse_args(argv)

    log_path: Path = args.logfile
    if not log_path.exists():
        print(f"Error: file not found: {log_path}", file=sys.stderr)
        return 1

    total, valid, violations = validate_file(
        log_path, check_secrets=args.check_secrets
    )

    # ── Summary output ────────────────────────────────────────────────────
    print(f"File: {log_path}")
    print(f"Total lines:  {total}")
    print(f"Valid lines:  {valid}")
    print(f"Violations:   {len(violations)}")

    if violations:
        print()
        print("Violations:")
        for v in violations:
            print(str(v))
        return 1

    print()
    print("OK -- no violations found.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
