"""
Entry point for ``python -m app_logger``.

Dispatches to available subcommands:

    python -m app_logger validate logfile.log [--check-secrets]
"""

from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> int:
    """Top-level dispatcher for ``python -m app_logger``."""
    parser = argparse.ArgumentParser(
        prog="python -m app_logger",
        description="app_logger CLI utilities.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # ── validate subcommand ───────────────────────────────────────────────
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate an NDJSON log file against the app_logger schema.",
    )
    validate_parser.add_argument(
        "logfile",
        help="Path to the NDJSON log file to validate.",
    )
    validate_parser.add_argument(
        "--check-secrets",
        action="store_true",
        default=False,
        help="Scan all string values for secret patterns.",
    )

    args = parser.parse_args(argv)

    if args.command == "validate":
        from .validate import main as validate_main
        from pathlib import Path

        # Rebuild argv for the validate module's own parser
        validate_argv = [args.logfile]
        if args.check_secrets:
            validate_argv.append("--check-secrets")
        return validate_main(validate_argv)

    # No subcommand provided -- print help
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
