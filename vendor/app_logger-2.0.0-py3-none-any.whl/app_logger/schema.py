"""
Log schema definitions for the app_logger package.

Provides TypedDict definitions for structured log entries, literal types
for controlled vocabularies, and constants shared across the package.
"""

from __future__ import annotations

from typing import Any, Literal, TypedDict

# ── Schema Version ────────────────────────────────────────────────────────────

SCHEMA_VERSION: str = "1"

# ── Controlled Vocabularies ───────────────────────────────────────────────────

Level = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

Status = Literal["SUCCESS", "PARTIAL", "FAILED", "SKIPPED"]

EVENT_VOCABULARY: frozenset[str] = frozenset({
    "RUN_START",
    "RUN_END",
    "STEP_START",
    "STEP_END",
    "ERROR",
    "RETRY",
    "METRIC",
    "LOG",
    "RUN_SUMMARY",
})

# ── Log Entry TypedDict (split required / optional) ──────────────────────────


class _LogEntryRequired(TypedDict):
    """Tier 1 -- required on every line."""

    ts: str
    level: Level
    schema_version: str
    run_id: str
    app: str
    job: str
    event: str
    message: str
    logger: str
    host: str
    pid: int


class LogEntry(_LogEntryRequired, total=False):
    """Full log entry -- Tier 2 and Tier 3 fields are optional."""

    # Tier 2 -- lifecycle events
    status: Status
    step: str
    duration_s: float
    steps_total: int
    steps_success: int
    steps_failed: int
    steps_partial: int

    # Tier 3 -- contextual
    rows: int
    rows_failed: int
    table_name: str
    file_name: str
    source: str
    target: str
    error_type: str
    error_detail: str
    stack_trace: str
    error_category: str
    retryable: bool
    attempt: int
    max_attempts: int
    app_version: str
    trigger: str
    schedule: str
    run_type: str
    started_at: str
    ended_at: str
    extra: dict[str, Any]
