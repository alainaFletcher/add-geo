"""
app_logger -- Standardized NDJSON logging for scheduled Python applications.

Public API::

    from app_logger import AppLogger, generate_run_id, ExitCode, StepResult
    from app_logger import purge_old_logs, purge_old_index
"""

from __future__ import annotations

from .logger import AppLogger, ExitCode, StepResult, generate_run_id
from .purge import purge_old_index, purge_old_logs
from .schema import Status

__all__ = [
    "AppLogger",
    "ExitCode",
    "Status",
    "StepResult",
    "generate_run_id",
    "purge_old_logs",
    "purge_old_index",
]

__version__ = "2.1.0"
